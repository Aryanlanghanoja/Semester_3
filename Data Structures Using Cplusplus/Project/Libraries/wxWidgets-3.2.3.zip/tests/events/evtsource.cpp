///////////////////////////////////////////////////////////////////////////////
// Name:        tests/events/evtsource.cpp
// Purpose:     Test the event sources
// Author:      Bartosz Bekier
// Created:     2009-01-24
// Copyright:   (c) 2009 Bartosz Bekier <bartosz.bekier@gmail.com>
// Licence:     wxWindows licence
///////////////////////////////////////////////////////////////////////////////

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

#include "testprec.h"
